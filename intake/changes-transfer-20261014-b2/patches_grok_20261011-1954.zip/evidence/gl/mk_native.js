// builds t.html: compiles each easeBack variant with pow() lowered the way many mobile drivers do it (exp2(y*log2(x))) and counts NaN outputs
const fs=require('fs');
const get=f=>{const s=fs.readFileSync(f,'utf8');const m=s.match(/"(float easeBack\(float x\)\{[^"]*)"/);return m[1];};
const v={before:get(process.argv[2]),after:get(process.argv[3])};
const html=`<!doctype html><canvas id=c width=256 height=1></canvas><pre id=o></pre><script>
const V=${JSON.stringify(v)};const gl=document.getElementById('c').getContext('webgl2');const out={};
function run(src){const vs='#version 300 es\\nvoid main(){vec2 p=vec2(float((gl_VertexID<<1)&2),float(gl_VertexID&2));gl_Position=vec4(p*2.-1.,0.,1.);}';
const fsrc='#version 300 es\\nprecision highp float;\\nfloat powE(float x,float y){return exp2(y*log2(x));}\\n'+src+'\\nout vec4 o;void main(){float x=gl_FragCoord.x/256.;float e=easeBack(x);o=vec4(clamp(e/1.2,0.,1.),0,0,1);}';
function sh(t,s){const h=gl.createShader(t);gl.shaderSource(h,s);gl.compileShader(h);if(!gl.getShaderParameter(h,gl.COMPILE_STATUS))throw gl.getShaderInfoLog(h);return h;}
const p=gl.createProgram();gl.attachShader(p,sh(gl.VERTEX_SHADER,vs));gl.attachShader(p,sh(gl.FRAGMENT_SHADER,fsrc));gl.linkProgram(p);gl.useProgram(p);gl.drawArrays(gl.TRIANGLES,0,3);
const px=new Uint8Array(256*4);gl.readPixels(0,0,256,1,gl.RGBA,gl.UNSIGNED_BYTE,px);const ref=x=>{const c=1.7,y=x-1;return 1+(c+1)*y*y*y+c*y*y};let bad=0,ex=[];for(let i=0;i<256;i++){const x=(i+.5)/256;const want=Math.round(Math.min(1,Math.max(0,ref(x)/1.2))*255);if(Math.abs(px[i*4]-want)>2){bad++;if(ex.length<4)ex.push([+x.toFixed(3),px[i*4],want]);}}return {wrong_of_256:bad,examples_x_got_want:ex};}
for(const k in V){try{out[k]=run(V[k]);}catch(e){out[k]={error:String(e)};}}
document.getElementById('o').textContent=JSON.stringify(out);</script>`;
fs.writeFileSync('t.html',html);
