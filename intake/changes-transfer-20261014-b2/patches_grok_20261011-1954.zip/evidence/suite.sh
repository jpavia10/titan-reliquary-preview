#!/bin/bash
# runs the repo's existing tests + regression tests on every branch in a separate worktree
cd /workspace/tr-patch
PY="/workspace/.venv-patch/bin/python -W ignore"
OUT=/workspace/patchwork/suite; mkdir -p $OUT
for b in main grk-b01 grk-b02 grk-r02 grk-r01 grk-s01 grk-m03 grk-s02 grk-m01-m02; do
  wt=/tmp/wt-$b; rm -rf $wt; git worktree add -f -q --detach $wt $b
  ( cd $wt
    for t in tools/agents/test_homework.py tools/pipeline/test_migrations.py tools/pipeline/test_pipeline.py tools/bridge/test_intake.py $(git diff --name-only main..HEAD | grep -E 'test_regress.*\.py$'); do
      r=$($PY $t 2>&1 | tail -3 | tr '\n' ' '); echo "$b | $t | $r"
    done
    for t in $(git diff --name-only main..HEAD | grep -E 'test_regress.*\.js$'); do r=$(node $t 2>&1 | tail -2 | tr '\n' ' '); echo "$b | $t | $r"; done
  ) > $OUT/$b.txt 2>&1 &
done
wait
for b in main grk-b01 grk-b02 grk-r02 grk-r01 grk-s01 grk-m03 grk-s02 grk-m01-m02; do git worktree remove -f /tmp/wt-$b; done
cat $OUT/*.txt
