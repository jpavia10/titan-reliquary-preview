import json, os, sys, tempfile
ROOT = sys.argv[1]
sys.path[:0] = [os.path.join(ROOT, 'tools/pipeline'), os.path.join(ROOT, 'tools/bridge')]
import apply_changes as A
def ev(**kw):
    e = {"ts": "2026-10-11T08:30:00Z", "op": "set", "verified": False, "phase": 2, "confidence": "high", "entity": "specimen", "id": "C001", "field": "story"}
    e.update(kw); return e
def dry(lines, name="changes_grok_20261011-1950.jsonl"):
    d = tempfile.mkdtemp(); p = os.path.join(d, name)
    open(p, "w", encoding="utf-8").write("".join(json.dumps(x, ensure_ascii=False) + "\n" for x in lines))
    st, rep, _ = A.apply_file(p, os.path.join(ROOT, "collection"), dry_run=True, assignments={})
    return st, rep
if __name__ == "__main__":
    print(dry([ev(by="owner", new="Probe story by owner.", source="owner")]))
