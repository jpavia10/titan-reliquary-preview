import re, sys
def transform(s):
    out, i, n = [], 0, 0
    while True:
        k = s.find("pow(", i)
        if k < 0: out.append(s[i:]); break
        if k > 0 and (s[k-1].isalnum() or s[k-1] == "_"): out.append(s[i:k+4]); i = k + 4; continue
        # parse args with balanced parens, staying inside one JS string literal (no quotes inside)
        j, depth, comma = k + 4, 1, -1
        while j < len(s) and depth:
            c = s[j]
            if c in "\"'\n": break
            if c == "(": depth += 1
            elif c == ")": depth -= 1
            elif c == "," and depth == 1: comma = j
            j += 1
        if depth or comma < 0: out.append(s[i:k+4]); i = k + 4; continue
        a, b = s[k+4:comma], s[comma+1:j-1]
        if b.strip() in ("2.", "2.0"):
            out.append(s[i:k]); out.append("sq(" + a.strip() + ")"); n += 1
        else: out.append(s[i:j])
        i = j
    return "".join(out), n
if __name__ == "__main__":
    tot = 0
    for f in sys.argv[1:]:
        s = open(f).read(); t, n = transform(s); open(f, "w").write(t); print(f, n); tot += n
    print("total", tot)
