#!/bin/bash
# usage: run.sh <repo dir>  -> JSON {n, failed, warn}
cd /workspace/patchwork/fxh && ln -sfn "$1" repo && (python3 -m http.server 8766 >/dev/null 2>&1 & echo $! > srv.pid) && sleep 1
timeout 120 google-chrome --headless=new --no-sandbox --use-angle=swiftshader --enable-unsafe-swiftshader --virtual-time-budget=60000 --dump-dom http://localhost:8766/h.html 2>/dev/null | grep -o '<pre id="o">.*</pre>'
kill $(cat srv.pid)
