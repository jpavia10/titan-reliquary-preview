#!/bin/bash
cd /workspace/patchwork/fxh && ln -sfn "$1" repo && (python3 -m http.server 8766 >/dev/null 2>&1 & echo $! > srv.pid) && sleep 1
timeout 300 google-chrome --headless=new --no-sandbox --use-angle=swiftshader --enable-unsafe-swiftshader --virtual-time-budget=200000 --dump-dom "http://localhost:8766/h2.html?$2" 2>/dev/null | grep -o '<pre id="o">.*</pre>' | cut -c1-1500
kill $(cat srv.pid)
