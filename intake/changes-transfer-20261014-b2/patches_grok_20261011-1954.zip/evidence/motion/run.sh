#!/bin/bash
# run.sh <app-motion.js path> : prints results for OS {none,reduce} x choice {none,full,calm,off}
cd /workspace/patchwork/motion && cp "$1" app-motion.js && (python3 -m http.server 8767 >/dev/null 2>&1 & echo $! > srv.pid) && sleep 1
for os in none reduce; do for m in none full calm off; do
  flag=""; [ $os = reduce ] && flag="--force-prefers-reduced-motion"
  prof=$(mktemp -d)
  r=$(timeout 60 google-chrome --headless=new --no-sandbox --user-data-dir=$prof $flag --virtual-time-budget=3000 --dump-dom "http://localhost:8767/t.html?m=$m" 2>/dev/null | grep -o '<pre id="o">.*</pre>' | sed 's/<[^>]*>//g;s/&quot;/"/g')
  echo "OS=$os $r"; rm -rf $prof
done; done
kill $(cat srv.pid)
